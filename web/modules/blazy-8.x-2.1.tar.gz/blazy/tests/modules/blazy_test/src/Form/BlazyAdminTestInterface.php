<?php

namespace Drupal\blazy_test\Form;

use Drupal\blazy\Form\BlazyAdminInterface;

/**
 * Provides resusable admin functions or form elements.
 */
interface BlazyAdminTestInterface extends BlazyAdminInterface {}
