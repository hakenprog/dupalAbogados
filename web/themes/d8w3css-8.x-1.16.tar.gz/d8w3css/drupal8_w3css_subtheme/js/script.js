/**
 * @file
 * This file is to add any custom js for the drupal8 w3css subtheme.
 */

(function ($) {

  'use strict';

  Drupal.behaviors.customBehavior = {
      // Perform jQuery as normal in here.
  };

})(jQuery);
