Add all custom components styling files.

Component (SMACSS "module")
Reusable, discrete UI elements; components should form the bulk of Drupal’s CSS.

https://drupal.org/docs/develop/standards/css/css-file-organization-for-drupal-8
